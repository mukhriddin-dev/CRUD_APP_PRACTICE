import React , {useState} from "react";



const AddProduct = ({AddProducts}) => {

const [name,setName]=useState("");
const [type,setType]=useState("");
const [cost,setCost]=useState("");


  return (
    <div className="card w-50 p-2 text-center mx-auto">
      <p>Add product content</p>

      <input
        type="text"
        className="form-control w-50 mx-auto m-2"
        placeholder="name"
        value={name}
        onChange={(e)=>setName(e.target.value)}

      />

      <input
        type="text"
        className="form-control w-50 mx-auto m-2"
        placeholder="type"
        value={type}
        onChange={(e)=>setType(e.target.value)}

      />

      <input
        type="number"
        className="form-control w-50 mx-auto m-2"
        placeholder="cost"
        value={cost}
        onChange={(e)=>setCost(e.target.value)}

      />

      <button className="btn btn-success w-50 mx-auto m-1" onClick={ ()=>{
          return (
            AddProducts(name,type,cost),
            setName(''),
            setType(''),
            setCost('')
          )
      }} > add product</button>


    </div>
  );
};

export default AddProduct;
